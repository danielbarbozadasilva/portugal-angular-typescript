export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:3011/v1',
  stripePublicKey: 'pk_test_SEU_PUBLIC_KEY_AQUI',
}
