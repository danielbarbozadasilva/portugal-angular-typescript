export interface ICartItem {
  activityId: string;
  name: string;
  price: number;
  quantity: number;
  image?: string;
}
