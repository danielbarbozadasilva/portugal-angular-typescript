export type DocumentType = 'RG' | 'CPF' | 'Passaporte' | 'Cédula de Identidade' | 'Outro';

export interface IAddress {
  street: string;
  number: string;
  complement?: string;
  district: string;
  city: string;
  state: string;
  zipCode: string;
}

export interface IClient {
  _id?: string;
  user: string; // User ID
  name: string;
  birthDate: string;
  country?: string;
  documentType?: string; // Alterado para string opcional
  documentValue?: string; // Alterado para string opcional
  phones: string[];
  address: IAddress;
  cpf?: string;
  deleted?: boolean;
  paymentMethods?: string[]; // PaymentMethod IDs
  interests?: string[];

  /* Timestamps */
  createdAt?: Date;
  updatedAt?: Date;
}
