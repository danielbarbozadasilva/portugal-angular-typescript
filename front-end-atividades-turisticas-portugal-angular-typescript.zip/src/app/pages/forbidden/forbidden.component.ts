import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-forbidden',
  templateUrl: './forbidden.component.html',
})
export class ForbiddenComponent {}
