import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';

import { IActivity, IActivityFilters } from '../../core/models/models.activity';
import * as ActivityActions from '../../core/store/activity/activity.actions';
import { selectAllActivities, selectActivityError, selectActivityCurrentPage, selectActivityTotalPages } from '../../core/store/activity/activity.selectors'; // Adicionar seletores de paginação se existirem

import { SearchActivitiesComponent } from '../../components/pages/home/search-activities/search-activities.component';
import { HeroComponent } from '../../components/pages/home/hero/hero.component';
import { ShowcaseComponent } from '../../components/pages/home/show-case/showcase.component';
import { ApresentationComponent } from '../../components/pages/home/apresentation/apresentation.component';
import { GastronomyComponent } from '../../components/pages/home/gastronomy/gastronomy.component';
import { PaginationComponent } from '../../components/pages/home/pagination/pagination.component';

@Component({
  standalone: true,
  selector: 'app-home-page',
  templateUrl: './home.component.html',
  imports: [
    CommonModule,
    SearchActivitiesComponent,
    HeroComponent,
    ShowcaseComponent,
    ApresentationComponent,
    GastronomyComponent,
    PaginationComponent, // Adicionar PaginationComponent aos imports
  ],
})
export class HomeComponent implements OnInit, OnDestroy {
  title = 'Home';
  activities: IActivity[] = [];

  currentPage: number = 1;
  itemsPerPage: number = 10; // Ajustar conforme necessário
  totalPages: number = 1;

  filters: IActivityFilters = {
    keyword: '',
    category: '',
    startDate: '',
    endDate: '',
    minPrice: '',
    maxPrice: '',
    language: '',
    lat: '',
    lng: '',
    sort: '',
  };

  private destroy$ = new Subject<void>();

  constructor(
    private store: Store, // Tipar Store, se quiser: private store: Store<AppState>
    private translate: TranslateService
  ) {
    // Configurações iniciais do ngx-translate
    this.translate.addLangs(['pt-PT', 'pt-BR', 'en-US', 'es-ES', 'fr-FR']);
    this.translate.setDefaultLang('pt-BR');
  }

  ngOnInit(): void {
    this.store
      .select(selectAllActivities)
      .pipe(takeUntil(this.destroy$))
      .subscribe((activitiesFromStore: IActivity[]) => {
        this.activities = activitiesFromStore;
      });

    this.store
      .select(selectActivityCurrentPage)
      .pipe(takeUntil(this.destroy$))
      .subscribe((page) => {
        this.currentPage = Number(page) ?? 1;
      });

    this.store
      .select(selectActivityTotalPages)
      .pipe(takeUntil(this.destroy$))
      .subscribe((pages) => {
        this.totalPages = Number(pages) ?? 1;
      });


    this.store
      .select(selectActivityError)
      .pipe(takeUntil(this.destroy$))
      .subscribe((error: any) => {
        if (error) {
          console.error('[HomeComponent] Error from Activity Store:', error);
          // Adicionar lógica para exibir erro ao usuário, se necessário
        }
      });

    this.fetchActivities(); // Carregar atividades iniciais
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  fetchActivities(): void {
    const filtersWithPagination = {
      ...this.filters,
      page: this.currentPage,
      limit: this.itemsPerPage,
    };
    // Disparar a ação correta para carregar atividades
    this.store.dispatch(ActivityActions.loadActivities({ filters: filtersWithPagination }));
  }

  // O método handleFilterChange precisa ser ajustado para receber { name: string; value: string }
  handleFilterChange({ name, value }: { name: string; value: string }): void {
    const filterName = name as keyof IActivityFilters;

    if (filterName === 'sort' && value === 'location') {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            this.filters = {
              ...this.filters,
              sort: value,
              lat: position.coords.latitude.toString(),
              lng: position.coords.longitude.toString(),
            };
            this.currentPage = 1; // Resetar para a primeira página ao mudar filtros
            this.fetchActivities();
          },
          (error) => {
            console.error('Erro ao obter localização:', error);
            // Tratar erro - talvez informar o usuário ou usar fallback
            this.filters = {
              ...this.filters,
              sort: value, // Manter o sort por localização, mas sem coords
              lat: '',
              lng: '',
            };
            this.currentPage = 1;
            this.fetchActivities();
          }
        );
      } else {
        console.error('Geolocalização não é suportada pelo navegador.');
        // Informar o usuário que a ordenação por localização não está disponível
        this.filters = {
          ...this.filters,
          sort: value,
          lat: '',
          lng: '',
        };
        this.currentPage = 1;
        this.fetchActivities();
      }
    } else {
      // Garantir que 'name' é uma chave válida de IActivityFilters
      if (filterName in this.filters) {
        this.filters = { ...this.filters, [filterName]: value };
        // Não buscar automaticamente a cada mudança de input/select, esperar o botão "Buscar"
      }
    }
  }

  handleSearch(): void {
    this.currentPage = 1; // Resetar para a primeira página ao buscar
    this.fetchActivities();
  }

  handlePageChange(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.fetchActivities();
    }
  }
}
