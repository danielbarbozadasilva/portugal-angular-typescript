// src/app/dashboard/pages/dashboard-home/dashboard-home.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard-home',
  templateUrl: './dashboard-home.component.html',
})
export class DashboardHomeComponent {
  constructor() {}
}
