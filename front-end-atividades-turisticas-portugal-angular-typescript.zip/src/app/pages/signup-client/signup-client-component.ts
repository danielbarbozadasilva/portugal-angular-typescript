import { Component, OnInit, OnDestroy, inject, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, FormArray, Validators, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { tap, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Actions, ofType } from '@ngrx/effects'; // Import Actions and ofType
import { RouterModule } from '@angular/router'; // Import RouterModule

import { signUpClient, clearClientError, signUpClientSuccess } from '../../core/store/client/client.actions'; // Import actions
import { ClientState } from '../../core/store/client/client.reducer'; // Import state interface
import { selectClient, selectClientError, selectClientLoading } from '../../core/store/client/client.selectors'; // Import selectors
import { IClientRequest, IClient } from '../../core/models/models.client'; // Import interfaces
import { IResponseError } from '../../core/models/models.index';
import { AppState } from '../../core/store/app.state'; // Assuming AppState exists
import { strongPasswordValidator, passwordMatchValidator } from '../../validations/validations-signup'; // Import validators

@Component({
  selector: 'app-signup-client',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, TranslateModule, RouterModule], // Add RouterModule
  templateUrl: './signup-client.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush, // Use OnPush
})
export class SignUpClientComponent implements OnInit, OnDestroy {
  private fb = inject(FormBuilder);
  private store = inject<Store<AppState>>(Store); // Use AppState
  private actions$ = inject(Actions); // Inject Actions
  public translate = inject(TranslateService); // Inject TranslateService

  // Formulário com tipagem mais específica e confirmPassword
  signupForm!: FormGroup<{
    name: FormControl<string>;
    email: FormControl<string>;
    password: FormControl<string>;
    confirmPassword: FormControl<string>; // Add confirmPassword
    address: FormGroup<{
      street: FormControl<string>;
      city: FormControl<string>;
      country: FormControl<string>;
      // Add other address fields if needed (zipCode, state, etc.)
      zipCode: FormControl<string>;
      state: FormControl<string>;
      number: FormControl<string>;
      complement: FormControl<string>;
      neighborhood: FormControl<string>;
    }>;
    phones: FormArray<FormControl<string>>;
    termsAccepted: FormControl<boolean>; // Add termsAccepted
  }>;

  // Observables para estado NGRX
  loading$: Observable<boolean>;
  error$: Observable<IResponseError | string | null>; // Use union type

  // Sinais para mensagens e estado da UI
  errorMessage = signal<string>(null);
  successMessage = signal<string>(null);
  showPassword = signal(false);
  showConfirmPassword = signal(false);

  // Subscriptions
  private errorSubscription: Subscription | undefined;
  private successSubscription: Subscription | undefined;
  private formChangesSubscription: Subscription | undefined;

  // Flag para controle de submissão
  private formSubmitted = false;
  this.signupForm = this.fb.group({
    // ...
    agentType: ['', Validators.required],
    cpf: [''],
    cnpj: [''],
    companyName: [''],
    phone: ['', Validators.required],
    mobilePhone: ['', Validators.required],
    whatsapp: [''],
    address: this.fb.group({
      zipCode: ['', Validators.required],
      street: ['', Validators.required],
      // etc.
    }),
    bankDetails: this.fb.group({
      bank: [''],
      bankAgency: [''],
      bankAccount: [''],
      accountType: ['']
    }),
    // ...
    termsAccepted: [false, Validators.requiredTrue]
  });
  
  // Dados iniciais para reset
  private initialFormData = {
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    address: {
      street: '',
      city: '',
      country: 'Brasil', // Default country
      zipCode: '',
      state: '',
      number: '',
      complement: '',
      neighborhood: '',
    },
    phones: [''], // Start with one empty phone field
    termsAccepted: false,
  };

  constructor() {
    // Seletores de estado
    this.loading$ = this.store.select(selectClientLoading);
    this.error$ = this.store.select(selectClientError);
    // client$ is removed as success is handled via actions$
  }

  ngOnInit(): void {
    this.buildForm();
    this.subscribeToErrorChanges();
    this.subscribeToSuccessAction();
    this.subscribeToFormChanges();
  }

  ngOnDestroy(): void {
    this.errorSubscription?.unsubscribe();
    this.successSubscription?.unsubscribe();
    this.formChangesSubscription?.unsubscribe();
  }

  private buildForm(): void {
    // Construção do FormGroup com nonNullable e validadores
    this.signupForm = this.fb.nonNullable.group({
      name: [this.initialFormData.name, [Validators.required, Validators.minLength(3)]],
      email: [this.initialFormData.email, [Validators.required, Validators.email]],
      password: [this.initialFormData.password, [Validators.required, strongPasswordValidator()]],
      confirmPassword: [this.initialFormData.confirmPassword, [Validators.required]],
      address: this.fb.nonNullable.group({
        street: [this.initialFormData.address.street, Validators.required],
        city: [this.initialFormData.address.city, Validators.required],
        country: [this.initialFormData.address.country, Validators.required],
        zipCode: [this.initialFormData.address.zipCode, Validators.required], // Add required
        state: [this.initialFormData.address.state, Validators.required], // Add required
        number: [this.initialFormData.address.number, Validators.required], // Add required
        complement: [this.initialFormData.address.complement],
        neighborhood: [this.initialFormData.address.neighborhood, Validators.required], // Add required
      }),
      phones: this.fb.nonNullable.array(
        this.initialFormData.phones.map(phone => this.createPhoneControl(phone)), // Use helper to create controls
        Validators.required // Ensure at least one phone number
      ),
      termsAccepted: [this.initialFormData.termsAccepted, Validators.requiredTrue], // Terms must be accepted
    }, { validators: passwordMatchValidator('password', 'confirmPassword') }); // Add password match validator
  }

  // Helper to create a phone FormControl
  private createPhoneControl(value: string = ''): FormControl<string> {
    return this.fb.nonNullable.control(value, Validators.required);
  }

  private subscribeToErrorChanges(): void {
    this.errorSubscription = this.error$.subscribe(error => {
      if (error) {
        const message = typeof error === 'string' ? error : error.message;
        this.errorMessage.set(message || this.translate.instant('signup.errors.generic'));
        this.successMessage.set(null); // Clear success on new error
      } else {
        this.errorMessage.set(null);
      }
    });
  }

  private subscribeToSuccessAction(): void {
    this.successSubscription = this.actions$.pipe(
      ofType(signUpClientSuccess),
      tap(({ client }) => {
        this.successMessage.set(this.translate.instant('signup.successMessage', { name: client.name }));
        this.errorMessage.set(null);
        this.formSubmitted = false; // Reset submission flag
        this.signupForm.reset(this.initialFormData); // Reset form
        // Optional: Navigate after delay
        // setTimeout(() => this.router.navigate(['/signin']), 3000);
      })
    ).subscribe();
  }

   private subscribeToFormChanges(): void {
    // Clear general error message on form change
    this.formChangesSubscription = this.signupForm.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        tap(() => {
          if (this.errorMessage()) {
            this.store.dispatch(clearClientError()); // Dispatch clear error action
          }
          if (this.successMessage()) {
            this.successMessage.set(null); // Clear success message on interaction
          }
        })
      )
      .subscribe();
  }

  // Getter para acesso ao FormArray de telefones
  get phones(): FormArray<FormControl<string>> {
    return this.signupForm.get('phones') as FormArray<FormControl<string>>;
  }

  // Adiciona um novo campo de telefone
  addPhone(): void {
    this.phones.push(this.createPhoneControl());
  }

  // Remove um campo de telefone
  removePhone(index: number): void {
    if (this.phones.length > 1) { // Keep at least one phone field
      this.phones.removeAt(index);
    }
  }

  toggleShowPassword(): void {
    this.showPassword.set(!this.showPassword());
  }

  toggleShowConfirmPassword(): void {
    this.showConfirmPassword.set(!this.showConfirmPassword());
  }

  // Submissão do formulário
  submit(): void {
    this.formSubmitted = true;
    this.signupForm.markAllAsTouched();

    if (this.signupForm.invalid) {
      console.error('Formulário inválido. Erros:', this.getFormValidationErrors());
      this.focusFirstInvalidField();
      this.errorMessage.set(this.translate.instant('signup.errors.validation'));
      return;
    }

    this.errorMessage.set(null); // Clear previous errors
    this.successMessage.set(null);

    // Obtém os dados, excluindo confirmPassword
    const { confirmPassword, ...clientData } = this.signupForm.getRawValue();

    // Ajusta a estrutura para IClientRequest (se necessário)
    const clientPayload: IClientRequest = {
      ...clientData,
      // phones: clientData.phones.filter(phone => !!phone) // Filter empty phones if needed by backend
    };

    console.log('Dispatching signUpClient action with payload:', clientPayload);
    this.store.dispatch(signUpClient({ data: clientPayload }));
  }

  // --- Métodos Auxiliares (Validação, Foco, Erros) ---

  isInvalid(controlName: string, groupName?: string): boolean {
    const control = groupName ? this.signupForm.get(groupName)?.get(controlName) : this.signupForm.get(controlName);
    // Check control validity and consider if the form has been submitted
    return !!control?.invalid && (control.touched || control.dirty || this.formSubmitted);
  }

  // Check for form array control errors
  isPhoneInvalid(index: number): boolean {
    const control = this.phones.at(index);
    return !!control?.invalid && (control.touched || control.dirty || this.formSubmitted);
  }

  getErrorMessage(controlName: string, errorName: string, groupName?: string): string | null {
    const control = groupName ? this.signupForm.get(groupName)?.get(controlName) : this.signupForm.get(controlName);
    if (control?.hasError(errorName) && (control.touched || control.dirty || this.formSubmitted)) {
      const baseKey = groupName ? `signup.errors.${groupName}.${controlName}` : `signup.errors.${controlName}`;
      const errorKey = `${baseKey}.${errorName}`;
      const genericKey = `signup.errors.generic`;

      const translatedError = this.translate.instant(errorKey, {
        // Pass parameters for specific errors like minlength
        requiredLength: control.getError(errorName)?.requiredLength
      });

      if (translatedError === errorKey) {
        const genericControlKey = `${baseKey}.invalid`;
        const translatedGenericControl = this.translate.instant(genericControlKey);
        if (translatedGenericControl !== genericControlKey) {
          return translatedGenericControl;
        }
        return this.translate.instant(genericKey);
      }
      return translatedError;
    }
    return null;
  }

   getPhoneErrorMessage(index: number, errorName: string): string | null {
    const control = this.phones.at(index);
     if (control?.hasError(errorName) && (control.touched || control.dirty || this.formSubmitted)) {
        // Simple required message for phone for now
        if (errorName === 'required') {
            return this.translate.instant('validation.required');
        }
        // Add other phone-specific errors if needed
     }
     return null;
   }

  private getFormValidationErrors(): any {
    const errors: any = {};
    Object.keys(this.signupForm.controls).forEach((key) => {
      const control = this.signupForm.get(key);
      if (control instanceof FormGroup) {
        const groupErrors = this.getNestedFormErrors(control);
        if (Object.keys(groupErrors).length > 0) {
          errors[key] = groupErrors;
        }
      } else if (control instanceof FormArray) {
        const arrayErrors: any[] = [];
        control.controls.forEach((itemControl, index) => {
          if (itemControl.errors) {
            arrayErrors[index] = itemControl.errors;
          }
        });
        if (arrayErrors.length > 0) {
          errors[key] = arrayErrors;
        }
      } else if (control?.errors) {
        errors[key] = control.errors;
      }
    });
    if (this.signupForm.errors) {
      errors['formGroup'] = this.signupForm.errors;
    }
    return errors;
  }

  private getNestedFormErrors(formGroup: FormGroup): any {
    const nestedErrors: any = {};
    Object.keys(formGroup.controls).forEach((key) => {
      const control = formGroup.get(key);
      if (control instanceof FormGroup) {
        const groupErrors = this.getNestedFormErrors(control);
        if (Object.keys(groupErrors).length > 0) {
          nestedErrors[key] = groupErrors;
        }
      } else if (control?.errors) {
        nestedErrors[key] = control.errors;
      }
    });
    return nestedErrors;
  }

  private focusFirstInvalidField(): void {
    const controls = this.signupForm.controls;
    for (const name in controls) {
      if (controls[name as keyof typeof controls]?.invalid) {
        const control = controls[name as keyof typeof controls];
        if (control instanceof FormGroup) {
          // Focus within nested group
          for (const nestedName in control.controls) {
             if (control.controls[nestedName as keyof typeof control.controls]?.invalid) {
               const element = document.querySelector(\`[formControlName="\${nestedName}"]\`);
               if (element instanceof HTMLElement) {
                 element.focus();
                 return;
               }
             }
          }
        } else if (control instanceof FormArray) {
           // Focus within form array
           for (let i = 0; i < control.length; i++) {
             if (control.at(i).invalid) {
               // Query selector might need adjustment based on how array controls are rendered
               const element = document.querySelector(\`[formArrayName="\${name}"] [formControlName="\${i}"]\`);
               if (element instanceof HTMLElement) {
                 element.focus();
                 return;
               }
             }
           }
        } else {
          // Focus top-level control
          const element = document.querySelector(\`[formControlName="\${name}"]\`);
          if (element instanceof HTMLElement) {
            element.focus();
            return;
          }
        }
      }
    }
    // Fallback focus
    const formElement = document.querySelector('form');
    formElement?.focus();
  }
}
