import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { createClient } from '../../core/store/client/client.actions';
import { IClient } from '../../core/models/models.client';
import { SignUpClientComponent } from './signup-client-component';

@Component({
  standalone: true,
  selector: 'app-signup-client',
  template: `
    <div class="container mx-auto mt-10">
      <h1 class="text-xl font-bold text-center mb-8">
        {{ title }}
      </h1>
      <app-signup-client></app-signup-client>
    </div>
  `,
  imports: [SignUpClientComponent],
})
export class SignupClientPage {
  title = 'SignUp Client Page';

  constructor(
    private store: Store,
    private router: Router
  ) {}

  async onSubmit(formData: IClient) {
    const Client = formData as unknown as IClient;
    this.store.dispatch(createClient({ Client }));
    this.router.navigate(['/']);
  }
}
